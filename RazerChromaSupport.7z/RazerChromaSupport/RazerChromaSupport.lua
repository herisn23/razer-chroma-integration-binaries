local function CreateWatcherFrame(size, x, y)
    local frm = CreateFrame("Frame", nil, UIParent, BackdropTemplateMixin and "BackdropTemplate")
    frm:SetFrameStrata("MEDIUM")
    frm:SetMovable(false)
    frm:EnableMouse(false)
    frm:SetWidth(1)
    frm:SetHeight(1)
    frm:SetPoint("TOPLEFT", x, y)
    frm:SetBackdrop({
        bgFile = "Interface\\AddOns\\RazerChromaSupport\\Pixel",
        tile = false,
        edgeFile = "Interface\\AddOns\\RazerChromaSupport\\Pixel",
        edgeSize = size,
        insets = { left = 0, top = 0, right = 0, bottom = 0 }
    })
    frm:Show()
    return frm
end

local fs = 2
local x = 0
local y = 0
local HealthFrame = CreateWatcherFrame(fs, x, y)
x = fs - 1
local PowerFrame = CreateWatcherFrame(fs, x, y)
x = x + fs
local ClassFrame = CreateWatcherFrame(fs, x, y)


local function SetPixelColor(frame, r, g, b)
    frame:SetBackdropBorderColor(r, g, b, 1)
    frame:SetBackdropColor(r, g, b, 1)
end

function round(number, decimals)
    return (("%%.%df"):format(decimals)):format(number)
end

--set class color
local c = RAID_CLASS_COLORS[select(2, UnitClass("player"))]
SetPixelColor(ClassFrame, round(c.r, 2), round(c.g, 2), round(c.b, 2))

local function GetUnitHealthPerc(uid)
    local current = UnitHealth(uid)
    local max = UnitHealthMax(uid)
    local perc = current / max
    return perc
end

local function GetUnitPowerPerc(uid)
    local current = UnitPower(uid)
    local max = UnitPowerMax(uid)
    local perc = current / max
    return perc
end

local function InitialPixelate()
    local health = GetUnitHealthPerc("Player")
    local power = GetUnitPowerPerc("Player")

    SetPixelColor(HealthFrame, health, health, health)
    SetPixelColor(PowerFrame, power, power, power)
end

InitialPixelate()

local Frame = CreateFrame("Frame")
Frame:RegisterUnitEvent("UNIT_HEALTH", "player")
Frame:RegisterUnitEvent("UNIT_POWER_UPDATE", "player")
Frame:SetScript("OnEvent", function(f, event, uid, powerType)
    if event == "UNIT_HEALTH" then
        local perc = GetUnitHealthPerc(uid)
        SetPixelColor(HealthFrame, perc, perc, perc)
    end
    if event == "UNIT_POWER_UPDATE" then
        local perc = GetUnitPowerPerc(uid)
        SetPixelColor(PowerFrame, perc, perc, perc)
    end
end)